package com.example.enviardato;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class RecibirDato extends AppCompatActivity {
    TextView SpearofRuin;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recibir_dato);
        SpearofRuin = (TextView) findViewById(R.id.generadormensaje);

        Bundle recuperator = this.getIntent().getExtras();
        if (recuperator!=null){
            String texto=recuperator.getString("nombre");
            SpearofRuin.setText("" +texto);
        }

    }

    public void volver(View view) { Intent volveratras = new Intent(this,MainActivity.class);
        startActivity(volveratras);
    }


}