package com.example.enviardato;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText campodetexto1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Asignar valores
        campodetexto1 = (EditText) findViewById(R.id.EditTextName);

    }

   /* public void acceso(View view) { Intent entrarsistema = new Intent(this,RecibirDato.class);

    startActivity(entrarsistema);
    }
*/

    public void acceder(View view){
        switch (view.getId()) {
            case R.id.buttonEnviar:
                String texto= campodetexto1.getText().toString();

                Toast.makeText(this, "El texto agregado es: " +texto,Toast.LENGTH_SHORT).show();
                break;

            case R.id.button:
                Intent entrarsistema = new Intent(MainActivity.this,RecibirDato.class);
                Bundle bundle1=new Bundle();
                bundle1.putString("nombre", campodetexto1.getText().toString());
                entrarsistema.putExtras(bundle1);
                startActivity(entrarsistema);
                break;

        }
    }


    }